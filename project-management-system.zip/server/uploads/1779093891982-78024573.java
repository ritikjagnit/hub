import java.awt.*;
import java.awt.event.*;
implement class TextListener Example extendsFrameimplement TextListener{
TextFieldtext;
TextListenerExample(){
text=new TextField();
text.setBounds(100,100,200,30);
text.addTextListener(This);
add(Text);
setSize(400,300);
setLayout(null);
setVisible(True);
}
public void textValueChanged(TextEvent e){
System.out.println("Text changed:"+text.getText());
}
public static void main(String[]args){
newTextListenerExample();
}} 