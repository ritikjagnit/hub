const http = require('http');

const request = (options, postData = null) => {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(body); } catch (e) {}
        resolve({ statusCode: res.statusCode, headers: res.headers, body: json || body });
      });
    });

    req.on('error', (e) => reject(e));

    if (postData) {
      req.write(JSON.stringify(postData));
    }
    req.end();
  });
};

async function runTests() {
  console.log('🚀 Starting Master Prompt MVP Team Integration Tests...\n');
  let token = null;
  let testMember = null;

  // 1. Authenticate / Login as Admin
  try {
    const loginRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/auth/login',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, { email: 'admin@pms.com', password: 'admin123' });

    if (loginRes.statusCode === 200 && loginRes.body.token) {
      token = loginRes.body.token;
      console.log('✅ Test 1 (Admin Login): Passed.');
    } else {
      console.error('❌ Test 1 (Admin Login): Failed.', loginRes.statusCode, loginRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 1 (Admin Login): Error.', err.message);
    process.exit(1);
  }

  // 2. Fetch Active Team List via /api/team/members
  try {
    const listRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/members',
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (listRes.statusCode === 200 && Array.isArray(listRes.body)) {
      console.log(`✅ Test 2 (Fetch Team Members): Passed. Found ${listRes.body.length} active members.`);
      
      // Find a user who is not admin@pms.com
      testMember = listRes.body.find(u => u.email !== 'admin@pms.com');
      if (!testMember) {
        console.error('❌ Test 2: No non-admin members found in team list to run integration tests.');
        process.exit(1);
      }
      console.log(`👉 Selected target user for member workflow: "${testMember.username}" (${testMember.email}, ID: ${testMember.id}, Role: ${testMember.role})`);
    } else {
      console.error('❌ Test 2 (Fetch Team Members): Failed.', listRes.statusCode, listRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 2 (Fetch Team Members): Error.', err.message);
    process.exit(1);
  }

  // 3. Remove Member (Soft Delete: setting on_team: false via /api/team/remove/:userId)
  try {
    const removeRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/remove/${testMember.id}`,
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (removeRes.statusCode === 200) {
      console.log(`✅ Test 3 (Remove Member /api/team/remove/:userId): Passed.`);
    } else {
      console.error('❌ Test 3 (Remove Member): Failed.', removeRes.statusCode, removeRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 3 (Remove Member): Error.', err.message);
    process.exit(1);
  }

  // 4. Verify User is no longer in team members list
  try {
    const listResAfter = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/members',
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const found = listResAfter.body.some(u => u.id === testMember.id);
    if (!found) {
      console.log('✅ Test 4 (Verify Removed from List): Passed. User is no longer in active members.');
    } else {
      console.error('❌ Test 4 (Verify Removed from List): Failed. User still present in active members.');
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 4 (Verify Removed from List): Error.', err.message);
    process.exit(1);
  }

  // 5. Add user back to team with role: 'member' via /api/team/add
  try {
    const addRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/add',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    }, { userId: testMember.id, role: 'member' });

    if (addRes.statusCode === 200 && addRes.body.user && addRes.body.user.role === 'member') {
      console.log(`✅ Test 5 (Add User Back with Default Member Role /api/team/add): Passed. Added successfully.`);
    } else {
      console.error('❌ Test 5 (Add User Back): Failed.', addRes.statusCode, addRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 5 (Add User Back): Error.', err.message);
    process.exit(1);
  }

  // 6. Verify user is back in the active list and has the member role
  try {
    const listResBack = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/members',
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const activeUser = listResBack.body.find(u => u.id === testMember.id);
    if (activeUser && activeUser.role === 'member') {
      console.log('✅ Test 6 (Verify Added Back & Role): Passed. User is back in active list with role "member".');
    } else {
      console.error('❌ Test 6 (Verify Added Back & Role): Failed.', activeUser);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 6 (Verify Added Back & Role): Error.', err.message);
    process.exit(1);
  }

  // 7. Change Role to admin via /api/team/role/:userId
  try {
    const roleRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/role/${testMember.id}`,
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    }, { role: 'admin' });

    if (roleRes.statusCode === 200) {
      console.log(`✅ Test 7 (Change Role /api/team/role/:userId): Passed.`);
    } else {
      console.error('❌ Test 7 (Change Role): Failed.', roleRes.statusCode, roleRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 7 (Change Role): Error.', err.message);
    process.exit(1);
  }

  // 8. Verify role update to admin
  try {
    const listResAdmin = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/members',
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const finalUser = listResAdmin.body.find(u => u.id === testMember.id);
    if (finalUser && finalUser.role === 'admin') {
      console.log('✅ Test 8 (Verify Role changed to admin): Passed.');
    } else {
      console.error('❌ Test 8 (Verify Role changed to admin): Failed.', finalUser);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 8 (Verify Role): Error.', err.message);
    process.exit(1);
  }

  // 9. Search active members via /api/team/search?query=...
  try {
    const searchRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/search?query=${encodeURIComponent(testMember.username.substring(0, 3))}`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (searchRes.statusCode === 200 && Array.isArray(searchRes.body)) {
      const foundInSearch = searchRes.body.find(u => u.id === testMember.id);
      if (foundInSearch) {
        console.log(`✅ Test 9 (Search Active Members /api/team/search?query=...): Passed. Found in search results.`);
      } else {
        console.error('❌ Test 9 (Search Active Members): Failed. User not returned by active search.', searchRes.body);
        process.exit(1);
      }
    } else {
      console.error('❌ Test 9 (Search Active Members): Failed.', searchRes.statusCode, searchRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 9 (Search Active Members): Error.', err.message);
    process.exit(1);
  }

  // 11. Search registered users via /api/team/search-users?q=...
  try {
    const searchUsersRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/search-users?q=${encodeURIComponent(testMember.email)}`,
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (searchUsersRes.statusCode === 200 && Array.isArray(searchUsersRes.body)) {
      const foundUser = searchUsersRes.body.find(u => u.id === testMember.id);
      if (foundUser && foundUser.on_team === true) {
        console.log(`✅ Test 11 (Search Users /api/team/search-users?q=...): Passed. User found with on_team: true.`);
      } else {
        console.error('❌ Test 11 (Search Users): Failed. User not found or on_team status mismatch.', searchUsersRes.body);
        process.exit(1);
      }
    } else {
      console.error('❌ Test 11 (Search Users): Failed.', searchUsersRes.statusCode, searchUsersRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 11 (Search Users): Error.', err.message);
    process.exit(1);
  }

  // 12. Remove member, then add back by exact Email
  try {
    // Remove first
    await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/remove/${testMember.id}`,
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    // Add back by email
    const addByEmailRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/add',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    }, { email: testMember.email, role: testMember.role });

    if (addByEmailRes.statusCode === 200 && addByEmailRes.body.user && addByEmailRes.body.user.email === testMember.email) {
      console.log(`✅ Test 12 (Add Member by Email): Passed.`);
    } else {
      console.error('❌ Test 12 (Add Member by Email): Failed.', addByEmailRes.statusCode, addByEmailRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 12 (Add Member by Email): Error.', err.message);
    process.exit(1);
  }

  // 13. Remove member, then add back by exact Username
  try {
    // Remove first
    await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/remove/${testMember.id}`,
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    // Add back by username
    const addByUsernameRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/add',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    }, { username: testMember.username, role: testMember.role });

    if (addByUsernameRes.statusCode === 200 && addByUsernameRes.body.user && addByUsernameRes.body.user.username === testMember.username) {
      console.log(`✅ Test 13 (Add Member by Username): Passed.`);
    } else {
      console.error('❌ Test 13 (Add Member by Username): Failed.', addByUsernameRes.statusCode, addByUsernameRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 13 (Add Member by Username): Error.', err.message);
    process.exit(1);
  }

  console.log('\n🎉 ALL MASTER PROMPT MVP TEAM CRUD & ENHANCED SEARCH/ADD TESTS PASSED SUCCESSFULLY!');
}

runTests();

