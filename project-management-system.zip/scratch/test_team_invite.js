const http = require('http');

const request = (options, postData = null) => {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(body); } catch (e) {}
        resolve({ statusCode: res.statusCode, headers: res.headers, body: json || body });
      });
    });

    req.on('error', (e) => reject(e));

    if (postData) {
      req.write(JSON.stringify(postData));
    }
    req.end();
  });
};

async function runTests() {
  console.log('🚀 Starting Team Invite and Email Add Integration Tests...\n');
  let token = null;
  let adminToken = null;

  // 1. Authenticate / Login as Admin
  try {
    const loginRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/auth/login',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, { email: 'admin@pms.com', password: 'admin123' });

    if (loginRes.statusCode === 200 && loginRes.body.token) {
      adminToken = loginRes.body.token;
      console.log('✅ Test 1 (Admin Login): Passed.');
    } else {
      console.error('❌ Test 1 (Admin Login): Failed.', loginRes.statusCode, loginRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 1 (Admin Login): Error.', err.message);
    process.exit(1);
  }

  // 2. Fetch Active Team List
  try {
    const listRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/members',
      method: 'GET',
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });

    if (listRes.statusCode === 200 && Array.isArray(listRes.body)) {
      console.log(`✅ Test 2 (Fetch Team Members): Passed. Found ${listRes.body.length} active members.`);
    } else {
      console.error('❌ Test 2 (Fetch Team Members): Failed.', listRes.statusCode, listRes.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 2 (Fetch Team Members): Error.', err.message);
    process.exit(1);
  }

  // 3. Add by email - Non-existent email
  try {
    const res = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/add-by-email',
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminToken}`
      }
    }, { email: 'nonexistent_user_998877@example.com' });

    if (res.statusCode === 404 && res.body.message === 'User does not exist') {
      console.log('✅ Test 3 (Add by email - Non-existent email): Passed.');
    } else {
      console.error('❌ Test 3 (Add by email - Non-existent email): Failed.', res.statusCode, res.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 3 (Add by email - Non-existent email): Error.', err.message);
    process.exit(1);
  }

  // Setup: Ensure a test user is in the database and not on the team
  let testUserId = null;
  let testUserEmail = 'testinviteuser@example.com';
  let testUserToken = null;

  try {
    // 1. Register a new user
    const regRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/auth/register',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, {
      username: 'TestInviteUser',
      email: testUserEmail,
      password: 'password123',
      role: 'team_member' // standard role
    });

    if (regRes.statusCode === 201) {
      testUserId = regRes.body.userId;
      console.log(`👉 Seeded temporary user: "${testUserEmail}" (ID: ${testUserId})`);
    } else if (regRes.statusCode === 400 && regRes.body.message === 'Email already registered') {
      // Find existing user ID
      const loginRes = await request({
        hostname: 'localhost',
        port: 5000,
        path: '/api/auth/login',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      }, { email: testUserEmail, password: 'password123' });
      testUserId = loginRes.body.user.id;
      testUserToken = loginRes.body.token;
      console.log(`👉 Reused existing temporary user: "${testUserEmail}" (ID: ${testUserId})`);
    }

    // Ensure they are off the team initially
    await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/remove/${testUserId}`,
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });

    // Authenticate the test user to get token for joining later
    const testLoginRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/auth/login',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, { email: testUserEmail, password: 'password123' });
    testUserToken = testLoginRes.body.token;

  } catch (err) {
    console.error('❌ Failed seeding test user:', err.message);
    process.exit(1);
  }

  // 4. Add by Email - Successful
  try {
    const res = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/add-by-email',
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminToken}`
      }
    }, { email: testUserEmail });

    if (res.statusCode === 200 && res.body.user && res.body.user.email === testUserEmail) {
      console.log('✅ Test 4 (Add by email - Successful): Passed.');
    } else {
      console.error('❌ Test 4 (Add by email - Successful): Failed.', res.statusCode, res.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 4 (Add by email - Successful): Error.', err.message);
    process.exit(1);
  }

  // 5. Add by Email - Duplicate Prevention
  try {
    const res = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/add-by-email',
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminToken}`
      }
    }, { email: testUserEmail });

    if (res.statusCode === 400 && res.body.message === 'User already in team') {
      console.log('✅ Test 5 (Add by email - Duplicate prevention): Passed.');
    } else {
      console.error('❌ Test 5 (Add by email - Duplicate prevention): Failed.', res.statusCode, res.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 5 (Add by email - Duplicate prevention): Error.', err.message);
    process.exit(1);
  }

  // 6. Role Update - Valid roles
  try {
    const resValid = await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/role/${testUserId}`,
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminToken}`
      }
    }, { role: 'admin' });

    const resInvalid = await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/role/${testUserId}`,
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminToken}`
      }
    }, { role: 'invalid_role_998' });

    if (resValid.statusCode === 200 && resInvalid.statusCode === 400) {
      console.log('✅ Test 6 (Change Role validation admin/member): Passed.');
    } else {
      console.error('❌ Test 6 (Change Role validation): Failed.', resValid.statusCode, resInvalid.statusCode);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 6 (Change Role validation): Error.', err.message);
    process.exit(1);
  }

  // Remove test user from team to test Invite flow
  await request({
    hostname: 'localhost',
    port: 5000,
    path: `/api/team/remove/${testUserId}`,
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });

  // 7. Invite Create - Successful
  let inviteToken = null;
  try {
    const res = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/team/invite/create',
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminToken}`
      }
    }, { role: 'admin' });

    if (res.statusCode === 201 && res.body.token) {
      inviteToken = res.body.token;
      console.log('✅ Test 7 (Create Invite link): Passed.');
    } else {
      console.error('❌ Test 7 (Create Invite link): Failed.', res.statusCode, res.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 7 (Create Invite link): Error.', err.message);
    process.exit(1);
  }

  // 8. Invite Join - Successful
  try {
    const res = await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/invite/join/${inviteToken}`,
      method: 'POST',
      headers: { 
        'Authorization': `Bearer ${testUserToken}`
      }
    });

    if (res.statusCode === 200 && res.body.user && res.body.user.role === 'admin') {
      console.log('✅ Test 8 (Join team via Invite token): Passed.');
    } else {
      console.error('❌ Test 8 (Join team via Invite token): Failed.', res.statusCode, res.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 8 (Join team via Invite token): Error.', err.message);
    process.exit(1);
  }

  // 9. Invite Join - Single Use Verification
  try {
    const res = await request({
      hostname: 'localhost',
      port: 5000,
      path: `/api/team/invite/join/${inviteToken}`,
      method: 'POST',
      headers: { 
        'Authorization': `Bearer ${adminToken}` // another user tries to join
      }
    });

    if (res.statusCode === 400 && res.body.message === 'Invite link has already been used') {
      console.log('✅ Test 9 (Join Invite - Single use validation): Passed.');
    } else {
      console.error('❌ Test 9 (Join Invite - Single use validation): Failed.', res.statusCode, res.body);
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Test 9 (Join Invite): Error.', err.message);
    process.exit(1);
  }

  console.log('\n🎉 ALL INVITE LINK AND EMAIL ADD INTEGRATION TESTS PASSED SUCCESSFULLY!');
}

runTests();
