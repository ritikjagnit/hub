const prisma = require('../server/config/db');

async function main() {
  const users = await prisma.users.findMany({
    select: {
      id: true,
      username: true,
      email: true,
      role: true,
      on_team: true
    }
  });
  console.log("USERS:", JSON.stringify(users, null, 2));
  await prisma.$disconnect();
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
