const { PrismaClient } = require('../server/node_modules/@prisma/client');
const { PrismaBetterSqlite3 } = require('../server/node_modules/@prisma/adapter-better-sqlite3');
const path = require('path');

const dbPath = path.resolve(__dirname, '..', 'server', 'config', 'project.db');
const adapter = new PrismaBetterSqlite3({ url: "file:" + dbPath });
const prisma = new PrismaClient({ adapter });

async function run() {
  const users = await prisma.users.findMany();
  console.log('--- USERS IN DATABASE ---');
  users.forEach(u => {
    console.log(`ID: ${u.id} | Username: "${u.username}" | Email: "${u.email}" | Role: "${u.role}" | On Team: ${u.on_team}`);
  });
  console.log('-------------------------');
}

run().catch(console.error);
